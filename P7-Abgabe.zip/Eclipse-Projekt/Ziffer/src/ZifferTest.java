/**
 * Software-Engineering - P7
 * SS 15
 * Jeff Wagner, 544167
 */

public class ZifferTest extends Ziffer {

	/*
	private static void out(Object o) {
			System.out.println(o);
	}
	*/

	public static void c0_vl() {
		// Hier alle Testfaelle fuer C0 aus der VL.
		System.out.println(werteZiffernfolgeAus(".."));
		System.out.println(werteZiffernfolgeAus(".9"));
	}

	public static void c1_vl() {
		// Hier alle Testfaelle fuer C1 aus der VL.
		System.out.println(werteZiffernfolgeAus(".."));
		System.out.println(werteZiffernfolgeAus(".9"));
		System.out.println(werteZiffernfolgeAus("9"));
	}

	public static void bi_vl() {
		// Hier alle Testfaelle fuer BI aus der VL.
		System.out.println(werteZiffernfolgeAus(""));
		System.out.println(werteZiffernfolgeAus("z"));
		System.out.println(werteZiffernfolgeAus("."));
		System.out.println(werteZiffernfolgeAus("9"));
		System.out.println(werteZiffernfolgeAus(".."));
		System.out.println(werteZiffernfolgeAus(".9"));
		System.out.println(werteZiffernfolgeAus("9z"));
		System.out.println(werteZiffernfolgeAus("9."));
		System.out.println(werteZiffernfolgeAus("99"));
	}


	public static void feec() {
		// Hier alle Testfaelle, welche FEEC maximieren.
		System.out.println(werteZiffernfolgeAus("."));
		System.out.println(werteZiffernfolgeAus("1"));
	}

	public static  void c0() {
		// Hier alle Testfaelle, welche C0 maximieren.
		System.out.println(werteZiffernfolgeAus(".."));
		System.out.println(werteZiffernfolgeAus(".1"));
	}

	public static  void c1() {
		// Hier alle Testfaelle, welche C1 maximieren.
		System.out.println(werteZiffernfolgeAus(".."));
		System.out.println(werteZiffernfolgeAus("1.1"));
	}

	public static  void c2() {
		// Hier alle Testfaelle, welche C2 maximieren.
		System.out.println(werteZiffernfolgeAus("a"));
		System.out.println(werteZiffernfolgeAus(".."));
		System.out.println(werteZiffernfolgeAus("1.1"));
		System.out.println(werteZiffernfolgeAus(""));
	}

	public static  void mmcc() {
		// Hier alle Testfaelle, welche MMCC maximieren.
		System.out.println(werteZiffernfolgeAus("a"));
		System.out.println(werteZiffernfolgeAus(".."));
		System.out.println(werteZiffernfolgeAus("1.1"));
		System.out.println(werteZiffernfolgeAus(""));
		System.out.println(werteZiffernfolgeAus("."));
	}

	public static  void mcdc() {
		// Hier alle Testfaelle, welche MCDC maximieren.
		System.out.println(werteZiffernfolgeAus("a"));
		System.out.println(werteZiffernfolgeAus(".."));
		System.out.println(werteZiffernfolgeAus("1.1"));
		System.out.println(werteZiffernfolgeAus(""));
		System.out.println(werteZiffernfolgeAus("."));
		System.out.println(werteZiffernfolgeAus("a1"));
		System.out.println(werteZiffernfolgeAus("11"));
		System.out.println(werteZiffernfolgeAus("1"));
	}

	public static void c3() {
		// Hier alle Testfaelle, welche C3 maximieren.
		System.out.println(werteZiffernfolgeAus("a"));
		System.out.println(werteZiffernfolgeAus(".."));
		System.out.println(werteZiffernfolgeAus("1.1"));
		System.out.println(werteZiffernfolgeAus(""));
		System.out.println(werteZiffernfolgeAus("."));
		System.out.println(werteZiffernfolgeAus("a1"));
		System.out.println(werteZiffernfolgeAus("11"));
		System.out.println(werteZiffernfolgeAus("1"));
		System.out.println(werteZiffernfolgeAus("1.a"));
	}

	public static void bi() {
		// Hier alle Testfaelle, welche BI maximieren.
		System.out.println(werteZiffernfolgeAus("a"));
		System.out.println(werteZiffernfolgeAus(".."));
		System.out.println(werteZiffernfolgeAus("1.1"));
		System.out.println(werteZiffernfolgeAus(""));
		System.out.println(werteZiffernfolgeAus("."));
		System.out.println(werteZiffernfolgeAus("a1"));
		System.out.println(werteZiffernfolgeAus("1"));
		System.out.println(werteZiffernfolgeAus("11"));
		System.out.println(werteZiffernfolgeAus("111"));
		System.out.println(werteZiffernfolgeAus("1111"));	
		System.out.println(werteZiffernfolgeAus("11.."));
		System.out.println(werteZiffernfolgeAus("1.a"));
		System.out.println(werteZiffernfolgeAus("1.1a"));
		System.out.println(werteZiffernfolgeAus(".1a"));
		System.out.println(werteZiffernfolgeAus(".1"));
		System.out.println(werteZiffernfolgeAus("1."));
		System.out.println(werteZiffernfolgeAus(".11"));
		System.out.println(werteZiffernfolgeAus("a1.1a"));
		System.out.println(werteZiffernfolgeAus("1.11"));
		System.out.println(werteZiffernfolgeAus("1a."));
	}

	/**
	 * Aufruf der verschiedenen Hilfsmethoden (s.o.) fuer die Ermittlung der
	 * Ueberdeckungen.
	 */
	public static void main(String[] args) {
		//TODO: Hilfsmethoden rufen
		//c0_vl();
		//c1_vl();
		//bi_vl();
		//feec();
		//c0();
		//c1();
		//c2();
		//mmcc();
		//mcdc();
		//c3();
		bi();
	}

}